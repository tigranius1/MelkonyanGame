from django.contrib import admin
from .models import Game, Review

@admin.register(Game)
class GameAdmin(admin.ModelAdmin):
    list_display = ('title', 'genre', 'rating', 'release_date')
    list_filter = ('genre', 'rating')
    search_fields = ('title', 'description')

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('author_name', 'game', 'created_at')
    list_filter = ('created_at', 'game')
    search_fields = ('author_name', 'text')