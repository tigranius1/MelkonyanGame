from django.db import models
from django.urls import reverse

class Game(models.Model):
    """Модель видеоигры"""
    GAME_GENRES = [
        ('RPG', 'Ролевая'),
        ('ACTION', 'Экшн'),
        ('STRATEGY', 'Стратегия'),
        ('ADVENTURE', 'Приключения'),
        ('SHOOTER', 'Шутер'),
        ('RACING', 'Гонки'),
        ('SPORTS', 'Спортивная'),
        ('PUZZLE', 'Головоломка'),
    ]

    title = models.CharField('Название', max_length=200)
    genre = models.CharField('Жанр', max_length=50, choices=GAME_GENRES)
    rating = models.FloatField('Рейтинг', default=0.0)
    cover = models.ImageField('Обложка', upload_to='covers/', blank=True, null=True)
    description = models.TextField('Описание')
    system_requirements = models.TextField('Системные требования')
    release_date = models.DateField('Дата выхода', null=True, blank=True)
    is_classic = models.BooleanField('Классическая игра', default=False)

    class Meta:
        verbose_name = 'Видеоигра'
        verbose_name_plural = 'Видеоигры'

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('game_detail', args=[str(self.id)])


class Review(models.Model):
    """Отзыв к игре"""
    game = models.ForeignKey(Game, on_delete=models.CASCADE, related_name='reviews')
    author_name = models.CharField('Имя автора', max_length=100)
    text = models.TextField('Текст отзыва')
    created_at = models.DateTimeField('Дата', auto_now_add=True)

    class Meta:
        verbose_name = 'Отзыв'
        verbose_name_plural = 'Отзывы'

    def __str__(self):
        return f'Отзыв от {self.author_name} на {self.game.title}'