from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # Главная страница
    path('game/<int:game_id>/', views.game_detail, name='game_detail'),  # Страница игры
    path('best-month/', views.best_month, name='best_month'),  # Лучшее за месяц
    path('classic-collection/', views.classic_collection, name='classic_collection'),  # Коллекция классики
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
]