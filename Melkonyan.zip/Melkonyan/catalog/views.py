from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from .models import Game, Review

def index(request):
    games = Game.objects.all()
    print("ИГРЫ:", games)  # это должно быть в терминале
    print("КОЛИЧЕСТВО:", games.count())
    return render(request, 'index.html', {'games': games})

def game_detail(request, game_id):
    """Страница отдельной игры"""
    game = get_object_or_404(Game, id=game_id)
    reviews = game.reviews.all()
    return render(request, 'game_detail.html', {'game': game, 'reviews': reviews})

def best_month(request):
    """Лучшие игры месяца (топ-5 по рейтингу)"""
    best_games = Game.objects.all().order_by('-rating')[:5]  # топ-5 по рейтингу
    return render(request, 'best_month.html', {'games': best_games})

def classic_collection(request):
    """Коллекция классических игр"""
    classic_games = Game.objects.filter(is_classic=True)
    return render(request, 'classic_collection.html', {'games': classic_games})

def register(request):
    """Регистрация нового пользователя"""
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Аккаунт успешно создан! Теперь вы можете войти.')
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})

def user_login(request):
    """Авторизация пользователя"""
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Добро пожаловать, {username}!')
                return redirect('index')
            else:
                messages.error(request, 'Неверное имя пользователя или пароль')
        else:
            messages.error(request, 'Ошибка в форме')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def user_logout(request):
    """Выход из системы"""
    logout(request)
    messages.success(request, 'Вы вышли из системы')
    return redirect('index')